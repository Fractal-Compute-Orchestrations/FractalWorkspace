plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.frac_exp_20"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.frac_exp_20"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

//    //WindowManager
    implementation ("androidx.window:window:1.1.0-alpha03")
//
    // Tensorflow lite dependencies
    implementation ("org.tensorflow:tensorflow-lite:2.13.0")
    implementation ("org.tensorflow:tensorflow-lite-gpu:2.13.0")
    implementation ("org.tensorflow:tensorflow-lite-metadata:0.4.4")
    implementation ("org.tensorflow:tensorflow-lite-support:0.4.4")
    implementation ("org.tensorflow:tensorflow-lite-select-tf-ops:2.13.0")
////        implementation ("org.tensorflow:tensorflow-lite:2.9.0")
////        implementation ("org.tensorflow:tensorflow-lite-gpu:2.9.0")
////        implementation ("org.tensorflow:tensorflow-lite-support:0.4.2")
////        implementation ("org.tensorflow:tensorflow-lite-select-tf-ops:2.9.0")
//    implementation ("com.squareup.okhttp3:okhttp:4.12.0") // For HTTP networking
//    implementation 'org.tensorflow:tensorflow-lite:2.16.0") // For TFLite interpreter
//
    implementation ("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.4")

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}