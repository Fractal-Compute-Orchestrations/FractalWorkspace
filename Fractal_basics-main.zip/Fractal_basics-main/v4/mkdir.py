import os

os.makedirs('./Server/v4/tmp/model.ckpt', exist_ok=True)