import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
import os

SAVED_MODEL_DIR = "./Server/v4/saved_model"

fashion_mnist = tf.keras.datasets.fashion_mnist
(train_images, train_labels), (test_images, test_labels) = fashion_mnist.load_data()

train_images = (train_images / 255.0).astype(np.float32)
test_images = (test_images / 255.0).astype(np.float32)

train_labels = tf.keras.utils.to_categorical(train_labels)
test_labels = tf.keras.utils.to_categorical(test_labels)


# Load the TensorFlow SavedModel
loaded_saved_model = tf.saved_model.load(SAVED_MODEL_DIR)
saved_model_infer = loaded_saved_model.signatures['infer']

# Load the TFLite model from file
with open('./Server/v4/model.tflite', 'rb') as f:
    tflite_model_bytes = f.read()

# Create TFLite interpreter from the loaded file
interpreter = tf.lite.Interpreter(model_content=tflite_model_bytes)
interpreter.allocate_tensors()
tflite_infer = interpreter.get_signature_runner("infer")

# Run inference on both models
input_data = train_images[:1]  # Use the first image for comparison
logits_original = saved_model_infer(x=input_data)['logits'][0]
logits_lite = tflite_infer(x=input_data)['logits'][0]

# Compare logits
def compare_logits(logits):
    width = 0.35
    offset = width/2
    assert len(logits) == 2

    keys = list(logits.keys())
    plt.bar(x=np.arange(len(logits[keys[0]]))-offset,
            height=logits[keys[0]], width=0.35, label=keys[0])
    plt.bar(x=np.arange(len(logits[keys[1]]))+offset,
            height=logits[keys[1]], width=0.35, label=keys[1])
    plt.legend()
    plt.grid(True)
    plt.ylabel('Logit')
    plt.xlabel('ClassID')

    delta = np.sum(np.abs(logits[keys[0]] - logits[keys[1]]))
    plt.title(f"Total difference: {delta:.3g}")

plt.clf()  # Clear previous plot
compare_logits({'Original': logits_original, 'Lite': logits_lite})
plt.show()