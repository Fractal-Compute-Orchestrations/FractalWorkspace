import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
import os

# Paths
SAVED_MODEL_DIR = "./Server/v4/saved_model"
TFLITE_MODEL_PATH = './Server/v4/model.tflite'
CKPT_PATH = "./Server/v4/model.ckpt"

# Load sample data
fashion_mnist = tf.keras.datasets.fashion_mnist
(train_images, train_labels), _ = fashion_mnist.load_data()
train_images = (train_images / 255.0).astype(np.float32)
train_images = train_images.reshape(-1, 28, 28)  # if needed
input_data = train_images[:1]

# Load SavedModel
loaded_saved_model = tf.saved_model.load(SAVED_MODEL_DIR)
saved_model_infer = loaded_saved_model.signatures['infer']
logits_original = saved_model_infer(x=input_data)['logits'][0]

# Load TFLite model
with open(TFLITE_MODEL_PATH, 'rb') as f:
    tflite_model = f.read()

interpreter = tf.lite.Interpreter(model_content=tflite_model)
interpreter.allocate_tensors()
tflite_infer = interpreter.get_signature_runner("infer")

# Inference before restoring
logits_lite_before = tflite_infer(x=input_data)['logits'][0]

# Restore weights from .ckpt (if supported)
try:
    restore = interpreter.get_signature_runner("restore")
    restore(checkpoint_path=np.array(CKPT_PATH, dtype=np.string_))

    # Inference after restore
    logits_lite_after = tflite_infer(x=input_data)['logits'][0]
except Exception as e:
    print("Restore not supported in TFLite model or failed:", e)
    logits_lite_after = None

# Plotting helper
def compare_logits(logits_dict):
    width = 0.35
    offset = width / 2
    keys = list(logits_dict.keys())
    
    plt.clf()
    for i, key in enumerate(keys):
        x = np.arange(len(logits_dict[key])) + (i - 0.5) * offset * 2
        plt.bar(x, logits_dict[key], width=width, label=key)

    delta = 0
    if len(keys) == 2:
        delta = np.sum(np.abs(logits_dict[keys[0]] - logits_dict[keys[1]]))
    elif len(keys) == 3:
        delta = np.sum(np.abs(logits_dict[keys[0]] - logits_dict[keys[2]]))

    plt.legend()
    plt.grid(True)
    plt.ylabel("Logit")
    plt.xlabel("Class ID")
    plt.title(f"Total difference: {delta:.3f}")
    plt.show()

# Prepare logits dictionary
logits_to_compare = {
    "Original": logits_original,
    "Lite (Before Restore)": logits_lite_before,
}

if logits_lite_after is not None:
    logits_to_compare["Lite (After Restore)"] = logits_lite_after

compare_logits(logits_to_compare)
