# import numpy as np
# import tensorflow as tf

# # Load Fashion MNIST
# fashion_mnist = tf.keras.datasets.fashion_mnist
# (train_images, train_labels), (_, _) = fashion_mnist.load_data()

# # Preprocess: Normalize images to [0, 1] and one-hot encode labels
# train_images = (train_images / 255.0).astype(np.float32)
# train_labels = tf.keras.utils.to_categorical(train_labels, num_classes=10).astype(np.float32)

# # Save images and labels to binary files
# train_images.tofile('train_images.bin')
# train_labels.tofile('train_labels.bin')

import numpy as np
import tensorflow as tf

# Load Fashion MNIST
fashion_mnist = tf.keras.datasets.fashion_mnist
(train_images, train_labels), (_, _) = fashion_mnist.load_data()

# Preprocess: Normalize images to [0, 1] and one-hot encode labels
train_images = (train_images / 255.0).astype(np.float32)
train_labels = tf.keras.utils.to_categorical(train_labels, num_classes=10).astype(np.float32)

# Specify the number of images to save
num_images = 100  # Change this to the desired number of images

# Slice the arrays to keep only the specified number of images and labels
train_images = train_images[:num_images]  # Shape: [num_images, 28, 28]
train_labels = train_labels[:num_images]  # Shape: [num_images, 10]

# Save images and labels to binary files
train_images.tofile('./Server/v4/images_bin/train_images.bin')
train_labels.tofile('./Server/v4/images_bin/train_labels.bin')

print(f"Saved {num_images} images to train_images.bin and labels to train_labels.bin")